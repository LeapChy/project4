<h2> hello from abc blade </h2>
<?php  
    $name = 'sok';
    echo "<h3> $name </h3>";

?>

